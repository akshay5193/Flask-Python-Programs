from flask import Flask, render_template, redirect, request

app = Flask(__name__)


@app.route('/')
def index():
    return render_template("index.html")


@app.route('/result', methods=['POST'])
def print_survey():
    print("Got Post Info for the Survey")
    print(request.form)
    name_survey = request.form['name']
    location_survey = request.form['location']
    language_survey = request.form['language']
    comment_survey = request.form['comment']

    return render_template('result.html', name_template=name_survey, location_template=location_survey, language_template=language_survey, comment_template=comment_survey)


if __name__ == "__main__":
    app.run(debug=True)
